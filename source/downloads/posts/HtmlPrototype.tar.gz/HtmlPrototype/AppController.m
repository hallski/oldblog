//
//  AppController.m
//  HtmlPrototype
//
//  Created by Mikael Hallendal on 2009-04-30.
//  Copyright 2009 Mikael Hallendal. All rights reserved.
//

#import "AppController.h"
#import "PrototypeView.h"


@implementation AppController

- (void)awakeFromNib
{
	[sideBarView setPrototypeDelegate:self];
	[sideBarView loadBundleFile:@"sidebar"];
	
	[contentView loadBundleFile:@"content1"];
}

- (void)showViewOne
{
	[contentView loadBundleFile:@"content1"];
}

- (void)showViewTwo
{
	[contentView loadBundleFile:@"content2"];
}

@end
