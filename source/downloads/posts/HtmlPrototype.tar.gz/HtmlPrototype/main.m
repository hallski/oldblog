//
//  main.m
//  HtmlPrototype
//
//  Created by Mikael Hallendal on 2009-04-30.
//  Copyright 2009 Mikael Hallendal. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
