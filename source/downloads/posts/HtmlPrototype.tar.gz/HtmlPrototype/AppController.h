//
//  AppController.h
//  HtmlPrototype
//
//  Created by Mikael Hallendal on 2009-04-30.
//  Copyright 2009 Mikael Hallendal. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class PrototypeView;

@interface AppController : NSObject {
	IBOutlet PrototypeView *sideBarView;
	IBOutlet PrototypeView *contentView;
}

@end
