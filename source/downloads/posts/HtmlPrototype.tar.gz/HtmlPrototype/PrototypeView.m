/* The MIT License
 
 Copyright (c) 2009 Mikael Hallendal
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 */

#import "PrototypeView.h"

@implementation PrototypeView

- (id)initWithFrame:(NSRect)frameRect
{
	self = [super initWithFrame:frameRect
					  frameName:nil
					  groupName:nil];
	
	[self setPolicyDelegate:self];
		
	return self;
}

- (BOOL)requestIsLinkClick:(NSDictionary *)actionInformation
{
	NSInteger action = [[actionInformation objectForKey:WebActionNavigationTypeKey] intValue];
	return action == WebNavigationTypeLinkClicked;
}

- (void)webView:(WebView *)aWebView 
decidePolicyForNavigationAction:(NSDictionary *)actionInformation 
		request:(NSURLRequest *)request 
		  frame:(WebFrame *)frame 
decisionListener:(id < WebPolicyDecisionListener >)listener
{
	if ([self requestIsLinkClick:actionInformation]) {
		if ([@"method" isEqual:[[request URL] scheme]]) {
			SEL selector = NSSelectorFromString([[request URL] resourceSpecifier]);
			if ([prototypeDelegate respondsToSelector:selector]) {
				[prototypeDelegate performSelector:selector];
			}
		}
		[listener ignore];
	} else {
		[listener use];
	}
}

- (void)setPrototypeDelegate:(id)newPrototypeDelegate
{
	prototypeDelegate = newPrototypeDelegate;
}

- (void)loadBundleFile:(NSString *)bundleFileName
{
	NSBundle *bundle = [NSBundle mainBundle];
	
	NSString *filePath = [bundle pathForResource:bundleFileName
										  ofType:@"html"];
	if (!filePath) {
		return;
	}
	
	NSURL *url = [NSURL fileURLWithPath:filePath];
	[[self mainFrame] loadRequest:[NSURLRequest requestWithURL:url]];
}

@end
