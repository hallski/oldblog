//
//  main.m
//  ObjcMacRuby
//
//  Created by Mikael Hallendal on 2009-05-06.
//  Copyright Mikael Hallendal 2009. All rights reserved.
//

#import <MacRuby/MacRuby.h>

int main(int argc, char *argv[])
{
    return macruby_main("rb_main.rb", argc, argv);
}
